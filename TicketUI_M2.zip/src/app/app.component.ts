import { Component } from '@angular/core';
import { Ticket } from './ticket/ticket';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  ticket: Ticket = {};

  toggleCreate: boolean = false;
  toggleTicketList = false;
  title = 'TicketUI';


  ticketCreationDone(t: Ticket){
    this.ticket = t;
    this.toggleCreate = false;
  }
}

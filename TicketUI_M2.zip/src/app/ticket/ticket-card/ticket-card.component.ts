import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { Ticket } from './../ticket';

@Component({
  selector: 'app-ticket-card',
  templateUrl: './ticket-card.component.html',
  styleUrls: ['./ticket-card.component.css']
})
export class TicketCardComponent implements OnInit, OnChanges {
  @Input() ticket: Ticket={};
  handled: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }
  ngOnChanges(changes: SimpleChanges): void {
    let datestr = String(this.ticket.creationDate); 
    let datesplit = datestr.split("T");
    let noeTime = new Date().getTime();
    
  }

}

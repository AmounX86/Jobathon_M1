import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Ticket } from './../ticket';
import { AddressService } from '../address.service';
import { TicketService } from './../ticket.service';

@Component({
  selector: 'app-ticket-create',
  templateUrl: './ticket-create.component.html',
  styleUrls: ['./ticket-create.component.css']
})
export class TicketCreateComponent implements OnInit {
  @Output() ticketCreated = new EventEmitter<Ticket>();

  govs: string[]=[];
  cities: string[]=[];
  districts: string[]=[];

  ticket: Ticket={};

  constructor(private addressService: AddressService,
    private ticketService: TicketService
    ) { }

  ngOnInit(): void {
    this.addressService.getGovs().subscribe({
      next: r=>this.govs=r,
      error: err=>console.error(err)
    });
    this.addressService.getCities().subscribe({
      next: r=>this.cities=r,
      error: err=>console.error(err)
    });
    this.addressService.getDistricts().subscribe({
      next: r=>this.districts=r,
      error: err=>console.error(err)
    });
  }

  create(){
    this.ticket.ticketID = 0;
    this.ticket.creationDate = new Date();
    this.ticketService.ticketCreate(this.ticket).subscribe(
      {
        next: r=>this.ticket=r,
        error: err=>console.error(err),
        complete: ()=>this.ticketCreated.emit(this.ticket)
      }
    );
  }
}

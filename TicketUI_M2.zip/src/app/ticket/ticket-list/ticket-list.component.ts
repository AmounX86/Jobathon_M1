import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Ticket } from '../ticket';
import { TicketService } from './../ticket.service';

@Component({
  selector: 'app-ticket-list',
  templateUrl: './ticket-list.component.html',
  styleUrls: ['./ticket-list.component.css']
})
export class TicketListComponent implements OnInit, OnChanges {
  @Input() update: number = 0;
  firstRun: boolean = true;
  page: number = 0;

  tickets: Ticket[]=[];

  constructor(private ticketService: TicketService) { }

  ngOnInit(): void {
    this.refresh();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if(this.firstRun) return;
    this.refresh();
  }
  next(){
    this.page++;
    this.refresh();
  }
  refresh(){
    this.ticketService.ticketList(this.page).subscribe({
      next: r=>this.tickets = r,
      error: err=>console.error(err),
      complete: ()=>{
        this.firstRun = false;
      }
    })
  }
}

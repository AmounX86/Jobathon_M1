import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TicketRoutingModule } from './ticket-routing.module';
import { TicketComponent } from './ticket.component';
import { TicketCreateComponent } from './ticket-create/ticket-create.component';
import { TicketListComponent } from './ticket-list/ticket-list.component';
import { FormsModule } from '@angular/forms';
import { TicketCardComponent } from './ticket-card/ticket-card.component';


@NgModule({
  declarations: [
    TicketComponent,
    TicketCreateComponent,
    TicketListComponent,
    TicketCardComponent
  ],
  imports: [
    CommonModule,
    TicketRoutingModule,
    FormsModule
  ],
  exports: [
    TicketCreateComponent,
    TicketListComponent,
    TicketComponent
  ]
})
export class TicketModule { }

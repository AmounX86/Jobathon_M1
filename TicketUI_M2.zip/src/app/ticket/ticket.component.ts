import { Component, OnInit } from '@angular/core';
import { Ticket } from './ticket';

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.component.html',
  styleUrls: ['./ticket.component.css']
})
export class TicketComponent implements OnInit {
  ticket: Ticket = {};

  toggleCreate: boolean = false;
  toggleTicketList = false;
  update: number = 0;
  title = 'TicketUI';

  constructor() { }

  ngOnInit(): void {
  }

  ticketCreationDone(t: Ticket){
    this.ticket = t;
    this.toggleCreate = false;
    this.toggleTicketList = true;
    this.update++;
  }
}
